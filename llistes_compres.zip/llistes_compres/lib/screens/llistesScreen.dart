import 'package:flutter/material.dart';
import 'package:llistes_compres/model/llista.dart';
import 'package:llistes_compres/provider/llistaProvider.dart';
import 'package:provider/provider.dart';



class llisteScreen extends StatelessWidget {
  llisteScreen({this.supermercat, super.key});
  final String? supermercat;

  @override
  Widget build(BuildContext context) {
    var llistaProvi = Provider.of<Llistaprovider>(context);
    llistaProvi.superMercatActual = supermercat!;
    List<Map<String, dynamic>>? values=llistaProvi.llistaEnv;
     if (values == null) print("fdfsfsdfsdfsdfsdfsdsd");
     
     print(values);
    return Scaffold(
      
      body: Center(
        
        child: _creaLlistaProductes(values),
      ),
    );
  }

  dynamic _creaLlistaProductes(List<Map<String, dynamic>>? values) {
    if (values == null) {
      // Si la llista és nul·la retornem un indicador de progrés
     if (values==null) print("jknhdbfjhksdbhfkjds");
      return const CircularProgressIndicator();
    }
    return ListView.builder(
      itemCount: values.length,
      itemBuilder: (BuildContext context, int index) {
      
       llista llist =llista.fromMap(values[index]);
       
        
       
        return ListTile(
          title: Text(llist.nom),
          subtitle: Text('Data: ${llist.data}'),
          trailing: Text('Items: ${llist.items.length}'),
        );
      },
    );
  }
}
