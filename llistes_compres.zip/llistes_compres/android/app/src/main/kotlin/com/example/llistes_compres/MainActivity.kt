package com.example.llistes_compres

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
